package Testing_Spec_CSUSM_Webpage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Browser_info.Browser_class;
import Page_Object_design.CSUSM_Webpage;
import library.Utility;

public class Test_3_CSUSM_webpage_CampusLife extends BaseClass_extentReport {

	@Test
	public void verify_Campus_life_tab()
	{
		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_3_CSUSM_webpage_CampusLife", "Verify the campus life page");
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");
		
		WebDriver driver =  Browser_class.start_browser_func("firefox","https://www.csusm.edu/");
		CSUSM_Webpage verify = new CSUSM_Webpage(driver);
		test.pass("navigated to the csusm.edu");
		
		//Verify the web page heading, title and print it
		WebElement webpage_heading= driver.findElement(By.xpath("//*[@id='ga-hp-header-home']"));
		System.out.println(webpage_heading.getText());
		String page_title = driver.getTitle();
		System.out.println(page_title);
		Utility.captureScreenshots_CSUSM_webpage_test3(driver, "CSUSM Home page_1");
		test.pass("navigated to the csusm.edu Home page");

		//Scroll the web page down and take the screen shot	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		Utility.captureScreenshots_CSUSM_webpage_test3(driver, "CSUSM Home page_2");

		//go to Academics > Course Catalog
		verify.campus_life_tab_func();	
		verify.living_on_campus_subTab_func();
		test.pass("navigated to the Academics > Course Catalog page");
		String course_catalog_page_title = driver.getTitle();
		WebElement webpage_heading1= driver.findElement(By.xpath("//*[@id='maincontent']/div/h1"));
		System.out.println(webpage_heading1.getText());
		System.out.println(course_catalog_page_title);
		Utility.captureScreenshots_CSUSM_webpage_test3(driver, "Living on Campus page");

		driver.quit();

	}

}
