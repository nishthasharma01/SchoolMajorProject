package Page_Object_design;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.xmlbeans.impl.util.Base64;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class CSUSM_Webpage {
	
	WebDriver driver;
	
	//CSUSM Webpage elements
	By acadamics_tab = By.xpath("//*[@id='tnavmenu']/div[1]/div/div/div[2]/span");
	By course_catalog_tab = By.xpath("//*[@id='ga-hp-academics-course-lg']");
	By about_tab = By.xpath("//*[@id='tnavmenu']/div[1]/div/div/div[1]/span");
	By about_CSUSM_subTab = By.xpath("//*[@id='ga-hp-about-about-lg']");
	By campus_Life_tab = By.xpath("//*[@id='tnavmenu']/div[1]/div/div/div[3]/span");
	By living_On_campus_subTab = By.xpath("//*[@id='ga-hp-life-living-lg']");
	By search_catalog_dropdown = By.xpath("//*[@id='location']");
	By searchCatalog_TextBox = By.xpath("//*[@id='keyword']");
	By search_icon = By.xpath("//*[@id='keyword-submit-icon']/span[1]");
	By course_prefixCode = By.xpath("//*[@id='gateway-page']/body/table/tbody/tr[3]/td[2]/table/tbody/tr[2]/td[2]/table/tbody/tr/td/table[2]/tbody/tr[1]/td[1]");
	By course_prefixC = By.xpath("//*[@id='gateway-page']/body/table/tbody/tr[3]/td[2]/table/tbody/tr[2]/td[2]/table/tbody/tr/td/table[2]/tbody/tr[2]/td");
	By admissionAndAid = By.xpath("//*[@id='tnavmenu']/div[1]/div/div/div[4]/span");
	By admissions_StudentOutReach = By.xpath("//*[@id='ga-hp-admissions-admissions-lg']");
	By resources = By.xpath("//*[@id='tnavmenu']/div[1]/div/div/div[6]/span");
	By staff_resources = By.xpath("//*[@id='ga-hp-resources-fs-lg']");
	By class_schedule = By.xpath("//*[@id='ga-hp-academics-schedule-lg']");
	By browse_search_courses_btn = By.xpath("/html/body/div[5]/div[2]/div[4]/div/div[1]/div/p[4]/a");
	By subject_dropdown = By.xpath("//*[@id='SSR_CLSRCH_WRK_SUBJECT_SRCH$0']");
	By course_career_dropdown = By.xpath("//*[@id='SSR_CLSRCH_WRK_ACAD_CAREER$2']");
	By search_button = By.xpath("//*[@id='CLASS_SRCH_WRK2_SSR_PB_CLASS_SRCH']");
	By modify_search_btn = By.xpath("//*[@id='CLASS_SRCH_WRK2_SSR_PB_MODIFY$5$']");
	By clear_search_btn = By.xpath("/html/body/form/div[5]/table/tbody/tr/td/div/table/tbody/tr[4]/td[2]/div/table/tbody/tr[2]/td/table/tbody/tr[5]/td[2]/div/table/tbody/tr/td/table/tbody/tr[2]/td[2]/div/a/span/input");
	By collegeDept_btn = By.xpath("//*[@id='ga-hp-academics-colleges-lg']");
	By collegeDept_Homebtn = By.xpath("/html/body/div[5]/div[2]/div[1]/div/ul/li[1]/a/span");
	By certificate_radioBtn = By.xpath("/html/body/div[5]/div[2]/div[4]/div/div[1]/div/fieldset/label[2]/input");
	By bachelor_radioBtn = By.xpath("/html/body/div[5]/div[2]/div[4]/div/div[1]/div/fieldset/label[3]/input");
	By minor_radioBtn = By.xpath("/html/body/div[5]/div[2]/div[4]/div/div[1]/div/fieldset/label[4]/input");
	By master_radioBtn = By.xpath("/html/body/div[5]/div[2]/div[4]/div/div[1]/div/fieldset/label[5]/input");
	By credential_radioBtn = By.xpath("/html/body/div[5]/div[2]/div[4]/div/div[1]/div/fieldset/label[6]/input");
	
	//constructor
	public CSUSM_Webpage(WebDriver driver)
	{
		this.driver=driver;	
	}
	
	//Academics tab
	public void academics_tab_func()
	{
		driver.findElement(acadamics_tab).click();
	}

	//Course catalog sub tab
	public void course_catalog_func()
	{
		driver.findElement(course_catalog_tab).click();
	}
	
	//ABOUT tab
	public void about_tab_func()
	{
		driver.findElement(about_tab).click();
	}

	//About CSUSM sub tab
	public void about_CSUSM_subTab_func()
	{
		driver.findElement(about_CSUSM_subTab).click();
	}
	
	//Campus Life tab
	public void campus_life_tab_func()
	{
		driver.findElement(campus_Life_tab).click();
	}

	//Living On Campus sub tab
	public void living_on_campus_subTab_func()
	{
		driver.findElement(living_On_campus_subTab).click();
	}
	
	public void catalog_search_dd_func()
	{
		driver.findElement(search_catalog_dropdown).click();
	}
	
	public void catalog_search_dd_sendkeys_func(String course)
	{
		driver.findElement(search_catalog_dropdown).sendKeys(course);
	}
	
	public void catalog_search_textBox_func()
	{
		driver.findElement(searchCatalog_TextBox).click();
	}
	
	public void catalog_search_textBox_sendkeys_func(String course_name)
	{
		driver.findElement(searchCatalog_TextBox).sendKeys(course_name);
	}
	
	//Class Schedule tab
	public void class_schedule_func()
	{
		driver.findElement(class_schedule).click();
	}
	
	//Browser/Search courses button
	public void browse_search_course_func(){
		driver.findElement(browse_search_courses_btn).click();
	}
	
	public void subject_dd_func()
	{
		driver.findElement(subject_dropdown).click();
	}
	
	public void subject_dd_sendkeys_func(String subject_name)
	{
		driver.findElement(subject_dropdown).sendKeys(subject_name);
	}
	
	public void course_career_dd_func()
	{
		driver.findElement(course_career_dropdown).click();
	}
	
	public void course_career_dd_sendkeys_func(String course_name)
	{
		driver.findElement(course_career_dropdown).sendKeys(course_name);
	}
	
	public void search_button_func()
	{
		driver.findElement(search_button).click();
	}
	
	public void modify_search_button_func()
	{
		driver.findElement(modify_search_btn).click();
	}
	
	public void clear_search_button_func()
	{
		driver.findElement(clear_search_btn).click();
	}
	
	//Function to enter the course from excel
	public void catalog_search_textBox_from_excel() throws Exception{
		
		File src = new File("E:\\nishtha\\CSUSM third sem\\Major Project\\Project\\TestData1.xlsx");
		FileInputStream fis = new FileInputStream(src);
		XSSFWorkbook wb2 = new XSSFWorkbook (fis); 
		XSSFSheet course_sheet = wb2.getSheetAt(0);
		int rowcount = course_sheet.getLastRowNum();
		System.out.println("Row count is:"+rowcount+1);
		
		for (int i=0; i<=rowcount; i++)
		{
		String data1 = course_sheet.getRow(i).getCell(0).getStringCellValue();
		System.out.println("Excel data is:"+data1);
		driver.findElement(searchCatalog_TextBox).sendKeys(data1);
		driver.findElement(search_icon).click();
		}
		wb2.close();
		
	}
	
	public void search_icon_click_func()
	{
		driver.findElement(search_icon).click();
	}

	public void course_prefixCode_assert_func()
	{
		String course_perfix = driver.findElement(course_prefixCode).getText();
		//WebElement errorMessage= driver.findElement(By.xpath("//*[@id='errorText']"));
		Assert.assertEquals(course_perfix,"Courses - Prefix/Code Matches");
		System.out.println(course_perfix);
	}
	
	public void admissionAnd_Aid_func()
	{
		driver.findElement(admissionAndAid).click();
	}

	public void admissions_StudentOutReach_func()
	{
		driver.findElement(admissions_StudentOutReach).click();
	}
	
	public void resources_func()
	{
		driver.findElement(resources).click();
	}

	public void staff_resources_func()
	{
		driver.findElement(staff_resources).click();
	}
	
	public void collegeDept_func()
	{
		driver.findElement(collegeDept_btn).click();
	}
	
	public void collegeDeptHome_func()
	{
		driver.findElement(collegeDept_Homebtn).click();
	}
	
	public void certificate_radioBtn_func()
	{
		driver.findElement(certificate_radioBtn).click();
	}
	
	public void bachelor_radioBtn_func()
	{
		driver.findElement(bachelor_radioBtn).click();
	}
	
	public void minor_radioBtn_func()
	{
		driver.findElement(minor_radioBtn).click();
	}
	
	public void master_radioBtn_func()
	{
		driver.findElement(master_radioBtn).click();
	}
	
	public void credential_radioBtn_func()
	{
		driver.findElement(credential_radioBtn).click();
	}
	
}

