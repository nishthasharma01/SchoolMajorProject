package Testing_Spec_cougar_course;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Browser_info.Browser_class;
import Page_Object_design.CougarCourse_app;
import library.Utility;

public class Test_3_CC_Profile_tab extends BaseClass_extentReport_cc {

	@Test
	public void verify_profile_tab () throws Exception
	{	
		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_2_CC_All_tabs", "Sample description");
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");

		WebDriver driver =  Browser_class.start_browser_func("chrome","https://www.csusm.edu/");
		CougarCourse_app access = new CougarCourse_app(driver);
		test.pass("navigated to the csusm.edu");
		
		JavascriptExecutor js = (JavascriptExecutor) driver;

		//Login into application
		access.generalFunc();
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(2000);
		Utility.captureScreenshots_cougarCourse_test3(driver, "Cougar Course");

		//		access.type_usernamefunc("username");
		//		Utility.captureScreenshots(driver, "username");
		//		access.type_passwordfunc("password");
		//		Utility.captureScreenshots(driver, "password");
		//		access.click_signIn_func();	

		//		access.enter_username_from_excel();
		//		Utility.captureScreenshots_cougarCourse(driver, "username");
		//		access.enter_password_from_excel();
		//		Utility.captureScreenshots_cougarCourse(driver, "password");
		//		access.click_signIn_func();
		String page_title = driver.getTitle();
		System.out.println(page_title);


		//profile tab
		access.profile_tab_func();
		Utility.captureScreenshots_cougarCourse_test3(driver, "profile_tab");
		String profile_page_title = driver.getTitle();
		System.out.println(profile_page_title);

		//go to edit profile page
		access.edit_profile_func();
		Utility.captureScreenshots_cougarCourse_test3(driver, "edit_profile_btn");
		String editProfile_page_title = driver.getTitle();
		System.out.println(editProfile_page_title);

		//navigate back to previous page
		driver.navigate().back();

		//go to grade overview page
		access.grade_overview_func();
		Utility.captureScreenshots_cougarCourse_test3(driver, "gradeOverview_btn");
		String gradeOverview_page_title = driver.getTitle();
		System.out.println(gradeOverview_page_title);

		access.my_courseBtn_func();

		driver.quit();

	}

}
