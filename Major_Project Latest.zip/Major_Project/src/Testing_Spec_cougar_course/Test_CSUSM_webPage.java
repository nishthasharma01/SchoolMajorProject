package Testing_Spec_cougar_course;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Browser_info.Browser_class;
import Page_Object_design.CougarCourse_app;
import Page_Object_design.CSUSM_Webpage;
import library.Utility;

public class Test_CSUSM_webPage extends BaseClass_extentReport_cc {

	@Test
	public void verify_CSUSM_webPage () throws Exception
	{
		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_2_CC_All_tabs", "Sample description");
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");	

		WebDriver driver =  Browser_class.start_browser_func("chrome","https://www.csusm.edu/");
		CSUSM_Webpage verify = new CSUSM_Webpage(driver);
		test.pass("navigated to the csusm.edu");
		
		WebElement webpage_heading= driver.findElement(By.xpath("//*[@id='ga-hp-header-home']"));
		System.out.println(webpage_heading.getText());
		String page_title = driver.getTitle();
		System.out.println(page_title);
		//Utility.captureScreenshots_cougarCourse(driver, "CSUSM main page");

		//go to Resources > Faculty/Staff Resources
		verify.resources_func();	
		verify.staff_resources_func();
		String course_catalog_page_title = driver.getTitle();
		System.out.println(course_catalog_page_title);
		WebElement webpage_heading1= driver.findElement(By.xpath("//*[@id='finaid-academic-resources']"));
		System.out.println(webpage_heading1.getText());

		//	Utility.captureScreenshots_cougarCourse(driver, "Resources page");

		driver.quit();
	}
}
