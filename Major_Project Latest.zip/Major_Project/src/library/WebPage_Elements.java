package library;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Browser_info.Browser_class;
import Page_Object_design.CougarCourse_app;

public class WebPage_Elements {

	public static void main(String args[]){
		
		WebDriver driver =  Browser_class.start_browser_func("chrome","https://www.csusm.edu/");
		
		List<WebElement> elements = driver.findElements(By.xpath("//*"));
		
		System.out.println(Integer.toString(elements.size()));
	//	System.out.println(elements);
		
		for(WebElement el:elements){
			System.out.println(el.getTagName() + " : "+ el.getText());
		//	System.out.println(elements);
		}
	}
	
}
