package Testing_Spec_CSUSM_Webpage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Browser_info.Browser_class;
import Page_Object_design.CSUSM_Webpage;
import library.Utility;

public class Test_7_CSUSM_Webpage_CollegeAndDepartments extends BaseClass_extentReport{
	@Test
	public void verify_collegeDepartment_webpage()
	{
		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_7_CSUSM_Webpage_CollegeAndDepartments", "Verify the college and departments");
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");

		WebDriver driver =  Browser_class.start_browser_func("chrome","https://www.csusm.edu/");
		CSUSM_Webpage verify = new CSUSM_Webpage(driver);
		test.pass("navigated to the csusm.edu");
		
		//Verify the web page heading, title and print it
		WebElement webpage_heading= driver.findElement(By.xpath("//*[@id='ga-hp-header-home']"));
		System.out.println(webpage_heading.getText());
		String page_title = driver.getTitle();
		System.out.println(page_title);
		Utility.captureScreenshots_CSUSM_webpage_test7(driver, "CSUSM Home page1");
		test.pass("navigated to the csusm.edu Home page");
		
		//Scroll the web page down and take the screen shot	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		Utility.captureScreenshots_CSUSM_webpage_test7(driver, "CSUSM Home page_2");	

		//go to Academics > Course Catalog
		verify.academics_tab_func();	
		test.pass("navigated to the Academics tab");
		verify.collegeDept_func();
		test.pass("navigated to the Academics > College & Departments");
		String collegeDept_page_title = driver.getTitle();
		System.out.println(collegeDept_page_title);
		Utility.captureScreenshots_CSUSM_webpage_test7(driver, "College & Departments page");	
		verify.collegeDeptHome_func();
		test.pass("navigated to the College & Departments Home page");
		Utility.captureScreenshots_CSUSM_webpage_test7(driver, "College & Departments Home page");
		verify.certificate_radioBtn_func();
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		Utility.captureScreenshots_CSUSM_webpage_test7(driver, "Certificate course details");
		verify.bachelor_radioBtn_func();
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		Utility.captureScreenshots_CSUSM_webpage_test7(driver, "Bachelor course details");
		verify.minor_radioBtn_func();
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		Utility.captureScreenshots_CSUSM_webpage_test7(driver, "minor course details");
		verify.master_radioBtn_func();
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		Utility.captureScreenshots_CSUSM_webpage_test7(driver, "Master course details");
		verify.credential_radioBtn_func();
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		Utility.captureScreenshots_CSUSM_webpage_test7(driver, "Credential course details");
		test.pass("Verified all the options");
		
		driver.quit();
	}
}
