package Testing_Spec_CSUSM_Webpage;

import java.io.FileOutputStream;
import java.io.PrintStream;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Browser_info.Browser_class;
import Page_Object_design.CougarCourse_app;
import Page_Object_design.CSUSM_Webpage;
import library.Utility;

public class Test_1_CSUSM_Webpage_courseCatalog extends BaseClass_extentReport {

	@Test
	public void verify_CSUSM_webPage () throws Exception
	{
		//		System.setOut(new PrintStream(new FileOutputStream("E:\\nishtha\\CSUSM third sem\\Major Project\\output.txt")));
		//		System.out.println("Thie is test output ");

		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_1_CSUSM_Webpage_courseCatalog", "Verify the course catalog page");
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");

		WebDriver driver =  Browser_class.start_browser_func("chrome","https://www.csusm.edu/");
		CSUSM_Webpage verify = new CSUSM_Webpage(driver);
		test.pass("navigated to the csusm.edu");

		//Verify the web page heading, title and print it
		WebElement webpage_heading= driver.findElement(By.xpath("//*[@id='ga-hp-header-home']"));
		System.out.println(webpage_heading.getText());
		String page_title = driver.getTitle();
		System.out.println(page_title);
		Utility.captureScreenshots_CSUSM_webpage_test1(driver, "CSUSM Home page_1");
		test.pass("navigated to the csusm.edu Home page");
		
		//Scroll the web page down and take the screen shot	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		Utility.captureScreenshots_CSUSM_webpage_test1(driver, "CSUSM Home page_2");

		//go to Academics > Course Catalog
		verify.academics_tab_func();	
		test.pass("navigated to the Academics tab");
		verify.course_catalog_func();
		test.pass("navigated to the Academics > Course Catalog");
		String course_catalog_page_title = driver.getTitle();
		WebElement webpage_heading1= driver.findElement(By.xpath("//*[@id='acalog-page-title']"));
		System.out.println(webpage_heading1.getText());
		System.out.println(course_catalog_page_title);
		Utility.captureScreenshots_CSUSM_webpage_test1(driver, "Course Catalog page");
		verify.catalog_search_dd_func();
		verify.catalog_search_dd_sendkeys_func("course");
		verify.catalog_search_textBox_func();
		test.pass("Entered the different courses");
		verify.catalog_search_textBox_from_excel();
		//verify.catalog_search_textBox_sendkeys_func("cs");
		//	verify.search_icon_click_func();
		verify.course_prefixCode_assert_func();

		driver.quit();
	}
}
