package Testing_Spec_cougar_course;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Browser_info.Browser_class;
import Page_Object_design.CougarCourse_app;
import library.Utility;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;

public class Test_2_CC_All_tabs extends BaseClass_extentReport_cc {

	@Test
	public void verify_all_tabs () throws Exception
	{
		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_2_CC_All_tabs", "Sample description");
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");

		WebDriver driver =  Browser_class.start_browser_func("chrome","https://www.csusm.edu/");
		CougarCourse_app access = new CougarCourse_app(driver);
		test.pass("navigated to the csusm.edu");
		JavascriptExecutor js = (JavascriptExecutor) driver;

		//Login into application
		access.generalFunc();
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(2000);
		Utility.captureScreenshots_cougarCourse_test2(driver, "Cougar Course");

		//		access.type_usernamefunc("username");
		//		Utility.captureScreenshots(driver, "username");
		//		access.type_passwordfunc("password");
		//		Utility.captureScreenshots(driver, "password");
		//		access.click_signIn_func();	

		access.enter_username_from_excel();
		Utility.captureScreenshots_cougarCourse_test2(driver, "username");
		access.enter_password_from_excel();
		Utility.captureScreenshots_cougarCourse_test2(driver, "password");
		access.click_signIn_func();
		String page_title = driver.getTitle();
		System.out.println(page_title);


		//profile tab
		access.profile_tab_func();
		Utility.captureScreenshots_cougarCourse_test2(driver, "profile_tab");
		String profile_page_title = driver.getTitle();
		System.out.println(profile_page_title);
		access.my_courseBtn_func();

		//Dashboard tab
		Thread.sleep(2000);
		access.dashboard_tab_func();
		Utility.captureScreenshots_cougarCourse_test2(driver, "Dashboard_tab");
		String dashboard_page_title = driver.getTitle();
		System.out.println(dashboard_page_title);
		Thread.sleep(5000);
		access.my_courseBtn_func();

		//Preference tab
		Thread.sleep(2000);
		access.prefrence_tab_func();
		Utility.captureScreenshots_cougarCourse_test2(driver, "Preference_tab");
		String prefrence_page_title = driver.getTitle();
		System.out.println(prefrence_page_title);
		Thread.sleep(2000);
		access.my_courseBtn_func();

		//Grades tab
		Thread.sleep(2000);
		access.grades_tab_func();
		Utility.captureScreenshots_cougarCourse_test2(driver, "grades_tab");
		String grade_page_title = driver.getTitle();
		System.out.println(grade_page_title);
		Thread.sleep(2000);
		access.my_courseBtn_func();

		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(2000);
		access.logout_func();

		driver.quit();

	}


}
