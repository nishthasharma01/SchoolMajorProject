package Testing_Spec_cougar_course;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import Browser_info.Browser_class;
import Page_Object_design.CougarCourse_app;
import library.Utility;

import org.apache.commons.io.FileUtils;

public class Test_1_CC_Login {

	@Test
	public void verify_login () throws Exception
	{
		
		//Browser_class browser = new Browser_class();
		
		
		WebDriver driver =  Browser_class.start_browser_func("chrome","https://www.csusm.edu/");
		CougarCourse_app login = new CougarCourse_app(driver);

		//Login into application
		login.generalFunc();
		Utility.captureScreenshots_cougarCourse_test1(driver, "Cougar Course");
		
//		login.enter_username_from_excel();
//		Utility.captureScreenshots_cougarCourse(driver, "username");
//		login.enter_password_from_excel();
//		Utility.captureScreenshots_cougarCourse(driver, "password");
//		login.click_signIn_func();
		String page_title = driver.getTitle();
		System.out.println(page_title);
		//Assert.assertEquals(login.invalid_creds_func(), "Incorrect user ID or password. Type the correct user ID and password, and try again.");
		//login.invalid_creds_func();
//		login.click_course_func();
		Utility.captureScreenshots_cougarCourse_test1(driver, "homepage");
//		login.logout_func();
		Thread.sleep(2000);
		driver.quit();

		
	}
}
