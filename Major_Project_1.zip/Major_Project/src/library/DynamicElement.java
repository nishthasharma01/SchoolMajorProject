package library;

import org.openqa.selenium.WebDriver;

import Browser_info.Browser_class;
import Page_Object_design.CougarCourse_app;

public class DynamicElement {

	public void dynamic_locator(){
		
		WebDriver driver =  Browser_class.start_browser_func("chrome","yahoo.com");
		CougarCourse_app login = new CougarCourse_app(driver);
		
	}
	
}
