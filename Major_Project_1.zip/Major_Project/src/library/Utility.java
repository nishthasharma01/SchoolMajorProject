package library;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Utility {
	
	//Capture the screenshot function
	public static void captureScreenshots_cougarCourse_test1 (WebDriver driver, String screenshotName){
	
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(source, new File("./ScreenShots_CougarCourse_test1/"+screenshotName+".png"));
		} 
		catch (Exception e) 
		{
		System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}	
	
	public static void captureScreenshots_cougarCourse_test2 (WebDriver driver, String screenshotName){
		
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(source, new File("./ScreenShots_CougarCourse_test2/"+screenshotName+".png"));
		} 
		catch (Exception e) 
		{
		System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}	
	
public static void captureScreenshots_cougarCourse_test3 (WebDriver driver, String screenshotName){
		
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(source, new File("./ScreenShots_CougarCourse_test3/"+screenshotName+".png"));
		} 
		catch (Exception e) 
		{
		System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}	

public static void captureScreenshots_cougarCourse_test4 (WebDriver driver, String screenshotName){
	
	TakesScreenshot ts = (TakesScreenshot)driver;
	File source = ts.getScreenshotAs(OutputType.FILE);
	try {
		FileUtils.copyFile(source, new File("./ScreenShots_CougarCourse_test4/"+screenshotName+".png"));
	} 
	catch (Exception e) 
	{
	System.out.println("Exception while taking screenshot"+e.getMessage());
	}	
}

public static void captureScreenshots_cougarCourse_test7 (WebDriver driver, String screenshotName){
	
	TakesScreenshot ts = (TakesScreenshot)driver;
	File source = ts.getScreenshotAs(OutputType.FILE);
	try {
		FileUtils.copyFile(source, new File("./ScreenShots_CougarCourse_test7/"+screenshotName+".png"));
	} 
	catch (Exception e) 
	{
	System.out.println("Exception while taking screenshot"+e.getMessage());
	}	
}
	
	public static void captureScreenshots_CSUSM_webpage_test1 (WebDriver driver, String screenshotName){
		
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(source, new File("./ScreenShots_webpage_test1/"+screenshotName+".png"));
		} 
		catch (Exception e) 
		{
		System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}	
	
	public static void captureScreenshots_CSUSM_webpage_test2 (WebDriver driver, String screenshotName){
		
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(source, new File("./ScreenShots_webpage_test2/"+screenshotName+".png"));
		} 
		catch (Exception e) 
		{
		System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}
	
public static void captureScreenshots_CSUSM_webpage_test3 (WebDriver driver, String screenshotName){
		
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(source, new File("./ScreenShots_webpage_test3/"+screenshotName+".png"));
		} 
		catch (Exception e) 
		{
		System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}

public static void captureScreenshots_CSUSM_webpage_test4 (WebDriver driver, String screenshotName){
	
	TakesScreenshot ts = (TakesScreenshot)driver;
	File source = ts.getScreenshotAs(OutputType.FILE);
	try {
		FileUtils.copyFile(source, new File("./ScreenShots_webpage_test4/"+screenshotName+".png"));
	} 
	catch (Exception e) 
	{
	System.out.println("Exception while taking screenshot"+e.getMessage());
	}	
}

public static void captureScreenshots_CSUSM_webpage_test5 (WebDriver driver, String screenshotName){
	
	TakesScreenshot ts = (TakesScreenshot)driver;
	File source = ts.getScreenshotAs(OutputType.FILE);
	try {
		FileUtils.copyFile(source, new File("./ScreenShots_webpage_test5/"+screenshotName+".png"));
	} 
	catch (Exception e) 
	{
	System.out.println("Exception while taking screenshot"+e.getMessage());
	}	
}
	
}
