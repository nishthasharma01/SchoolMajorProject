package Testing_Spec_CSUSM_Webpage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Browser_info.Browser_class;
import Page_Object_design.CSUSM_Webpage;
import library.Utility;

public class Test_4_CSUSM_Webpage_AandA extends BaseClass_extentReport {

	@Test
	public void verify_About_tab() 
	{

		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_1_CSUSM_Webpage_courseCatalog", "Sample description");
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");

		WebDriver driver =  Browser_class.start_browser_func("chrome","https://www.csusm.edu/");
		CSUSM_Webpage verify = new CSUSM_Webpage(driver);
		test.pass("navigated to the csusm.edu");

		//Verify the web page heading, title and print it
		WebElement webpage_heading= driver.findElement(By.xpath("//*[@id='ga-hp-header-home']"));
		System.out.println(webpage_heading.getText());
		String page_title = driver.getTitle();
		System.out.println(page_title);
		//	Utility.captureScreenshots_CSUSM_webpage(driver, "CSUSM main page1");


		//go to Admission and Aid tab 
		verify.admissionAnd_Aid_func();

		//go to Admission and Aid tab > Admission and Student OutReach tab
		verify.admissions_StudentOutReach_func();
		String admissionAndAid_page_title = driver.getTitle();
		System.out.println(admissionAndAid_page_title);
		WebElement webpage_heading1= driver.findElement(By.xpath("//*[@id='maincontent']/div/h1"));
		System.out.println(webpage_heading1.getText());
		Utility.captureScreenshots_CSUSM_webpage_test4(driver, "Admission and Student outreach page");


		driver.quit();	


	}
}
