package Page_Object_design;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CSUSM_Webpage {
	
	WebDriver driver;
	
	//CSUSM Webpage elements
	By acadamics_tab = By.xpath("//*[@id='tnavmenu']/div[1]/div/div/div[2]/span");
	By course_catalog_tab = By.xpath("//*[@id='ga-hp-academics-course-lg']");
	By about_tab = By.xpath("//*[@id='tnavmenu']/div[1]/div/div/div[1]/span");
	By about_CSUSM_subTab = By.xpath("//*[@id='ga-hp-about-about-lg']");
	By campus_Life_tab = By.xpath("//*[@id='tnavmenu']/div[1]/div/div/div[3]/span");
	By living_On_campus_subTab = By.xpath("//*[@id='ga-hp-life-living-lg']");
	
	//constructor
	public CSUSM_Webpage(WebDriver driver)
	{
		this.driver=driver;	
	}
	
	//Academics tab
	public void academics_tab_func()
	{
		driver.findElement(acadamics_tab).click();
	}

	//Course catalog sub tab
	public void course_catalog_func()
	{
		driver.findElement(course_catalog_tab).click();
	}
	
	//ABOUT tab
	public void about_tab_func()
	{
		driver.findElement(about_tab).click();
	}

	//About CSUSM sub tab
	public void about_CSUSM_subTab_func()
	{
		driver.findElement(about_CSUSM_subTab).click();
	}
	
	//Campus Life tab
	public void campus_life_tab_func()
	{
		driver.findElement(campus_Life_tab).click();
	}

	//Living On Campus sub tab
	public void living_on_campus_subTab_func()
	{
		driver.findElement(living_On_campus_subTab).click();
	}
	
}
