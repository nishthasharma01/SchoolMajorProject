package Testing_Spec_CSUSM_Webpage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import Browser_info.Browser_class;
import Page_Object_design.CougarCourse_app;
import Page_Object_design.CSUSM_Webpage;
import library.Utility;

public class Test_1_CSUSM_webPage {

	@Test
	public void verify_CSUSM_webPage () throws Exception
	{
		
		WebDriver driver =  Browser_class.start_browser_func("chrome","https://www.csusm.edu/");
		CSUSM_Webpage verify = new CSUSM_Webpage(driver);
		
	//Verify the web page heading, title and print it
		WebElement webpage_heading= driver.findElement(By.xpath("//*[@id='ga-hp-header-home']"));
		System.out.println(webpage_heading.getText());
		String page_title = driver.getTitle();
		System.out.println(page_title);
		Utility.captureScreenshots_CSUSM_webpage(driver, "CSUSM main page_1");
		
	//Scroll the web page down and take the screen shot	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		Utility.captureScreenshots_CSUSM_webpage(driver, "CSUSM main page_2");
		
	//go to Academics > Course Catalog
		verify.academics_tab_func();	
		verify.course_catalog_func();
		String course_catalog_page_title = driver.getTitle();
		WebElement webpage_heading1= driver.findElement(By.xpath("//*[@id='acalog-page-title']"));
		System.out.println(webpage_heading1.getText());
		System.out.println(course_catalog_page_title);
		Utility.captureScreenshots_CSUSM_webpage(driver, "Course Catalog page");
		
		driver.quit();
	}
}
