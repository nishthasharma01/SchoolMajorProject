package Testing_Spec_cougar_course;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Browser_info.Browser_class;
import Page_Object_design.CougarCourse_app;
import library.Utility;

public class Test_3_This_Course_tab {

	@Test
	public void verify_this_course_tab () throws Exception
	{
				
		WebDriver driver =  Browser_class.start_browser_func("chrome","https://www.csusm.edu/");
		CougarCourse_app access = new CougarCourse_app(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;

		//Login into application
		access.generalFunc();
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(2000);
		Utility.captureScreenshots_cougarCourse(driver, "Cougar Course");
		
//		access.type_usernamefunc("username");
//		Utility.captureScreenshots(driver, "username");
//		access.type_passwordfunc("password");
//		Utility.captureScreenshots(driver, "password");
//		access.click_signIn_func();	
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		access.lib_course_func();
		
		driver.quit();

		
	}

	
}
