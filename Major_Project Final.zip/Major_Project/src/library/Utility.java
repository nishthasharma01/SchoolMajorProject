package library;

import java.io.File;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utility {
	
	public static String timestamp() {
        return new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(new Date());
    }
	
	//Capture the screenshot function
	public void captureScreenshots_cougarCourse_test1 (WebDriver driver, String screenshotName){
	
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(source, new File("./CSUSM_CougarCourse_test1_execution/"+timestamp() +"  "+screenshotName +".png"));
			FileUtils.copyFile(source, new File("//E:\\Major Project\\CougarCourse_Test1\\"+timestamp() +"  "+screenshotName +".png"));
		} 
		catch (Exception e) 
		{
		System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}	
	
	public void captureScreenshots_cougarCourse_test2 (WebDriver driver, String screenshotName){
		
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(source, new File("./CSUSM_CougarCourse_test2_execution/"+timestamp() +"  "+screenshotName +".png"));
			FileUtils.copyFile(source, new File("//E:\\Major Project\\CougarCourse_Test2\\"+timestamp() +"  "+screenshotName +".png"));
		} 
		catch (Exception e) 
		{
		System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}	
	
	public void captureScreenshots_cougarCourse_test3 (WebDriver driver, String screenshotName){
		
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(source, new File("./CSUSM_CougarCourse_test3_execution/"+timestamp() +"  "+screenshotName +".png"));
			FileUtils.copyFile(source, new File("//E:\\Major Project\\CougarCourse_Test3\\"+timestamp() +"  "+screenshotName +".png"));
		
		} 
		catch (Exception e) 
		{
		System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}	

	public void captureScreenshots_cougarCourse_test4 (WebDriver driver, String screenshotName){
	
	TakesScreenshot ts = (TakesScreenshot)driver;
	File source = ts.getScreenshotAs(OutputType.FILE);
	try {
		FileUtils.copyFile(source, new File("./CSUSM_CougarCourse_test4_execution/"+timestamp() +"  "+screenshotName +".png"));
		FileUtils.copyFile(source, new File("//E:\\Major Project\\CougarCourse_Test4\\"+timestamp() +"  "+screenshotName +".png"));
	
	} 
	catch (Exception e) 
	{
	System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}

	public void captureScreenshots_cougarCourse_test5 (WebDriver driver, String screenshotName){
	
	TakesScreenshot ts = (TakesScreenshot)driver;
	File source = ts.getScreenshotAs(OutputType.FILE);
	try {
		FileUtils.copyFile(source, new File("./CSUSM_CougarCourse_test5_execution/"+timestamp() +"  "+screenshotName +".png"));
		FileUtils.copyFile(source, new File("//E:\\Major Project\\CougarCourse_Test5\\"+timestamp() +"  "+screenshotName +".png"));
	} 
	catch (Exception e) 
	{
	System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}
	
	public void captureScreenshots_CSUSM_webpage_test1 (WebDriver driver, String screenshotName){
		
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(source, new File("./CSUSM_Webpage_test1_execution/"+timestamp() +"  "+screenshotName +".png"));
			FileUtils.copyFile(source, new File("//E:\\Major Project\\CSUSM_Webpage_Test1\\"+timestamp() +"  "+screenshotName +".png"));
		} 
		catch (Exception e) 
		{
		System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}	
	
	public void captureScreenshots_CSUSM_webpage_test2 (WebDriver driver, String screenshotName){
		
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(source, new File("./CSUSM_Webpage_test2_execution/"+timestamp() +"  "+screenshotName +".png"));
			FileUtils.copyFile(source, new File("//E:\\Major Project\\CSUSM_Webpage_Test2\\"+timestamp() +"  "+screenshotName +".png"));
		} 
		catch (Exception e) 
		{
		System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}
	
	public void captureScreenshots_CSUSM_webpage_test3 (WebDriver driver, String screenshotName){
		
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(source, new File("./CSUSM_Webpage_test3_execution/"+timestamp() +"  "+screenshotName +".png"));
			FileUtils.copyFile(source, new File("//E:\\Major Project\\CSUSM_Webpage_Test3\\"+timestamp() +"  "+screenshotName +".png"));
		} 
		catch (Exception e) 
		{
		System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}

	public void captureScreenshots_CSUSM_webpage_test4 (WebDriver driver, String screenshotName){
	
	TakesScreenshot ts = (TakesScreenshot)driver;
	File source = ts.getScreenshotAs(OutputType.FILE);
	try {
		FileUtils.copyFile(source, new File("./CSUSM_Webpage_test4_execution/"+timestamp() +"  "+screenshotName +".png"));
		FileUtils.copyFile(source, new File("//E:\\Major Project\\CSUSM_Webpage_Test4\\"+timestamp() +"  "+screenshotName +".png"));
	} 
	catch (Exception e) 
	{
	System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}

	public void captureScreenshots_CSUSM_webpage_test5 (WebDriver driver, String screenshotName){
	
	TakesScreenshot ts = (TakesScreenshot)driver;
	File source = ts.getScreenshotAs(OutputType.FILE);
	try {
		FileUtils.copyFile(source, new File("./CSUSM_Webpage_test5_execution/"+timestamp() +"  "+screenshotName +".png"));
		FileUtils.copyFile(source, new File("//E:\\Major Project\\CSUSM_Webpage_Test5\\"+timestamp() +"  "+screenshotName +".png"));
	} 
	catch (Exception e) 
	{
	System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}

	public void captureScreenshots_CSUSM_webpage_test6 (WebDriver driver, String screenshotName){
	
	TakesScreenshot ts = (TakesScreenshot)driver;
	File source = ts.getScreenshotAs(OutputType.FILE);
	try {
		FileUtils.copyFile(source, new File("./CSUSM_Webpage_test6_execution/"+timestamp() +"  "+screenshotName +".png"));
		FileUtils.copyFile(source, new File("//E:\\Major Project\\CSUSM_Webpage_Test6\\"+timestamp() +"  "+screenshotName +".png"));
	} 
	catch (Exception e) 
	{
	System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}

	public void captureScreenshots_CSUSM_webpage_test7 (WebDriver driver, String screenshotName){
	
	TakesScreenshot ts = (TakesScreenshot)driver;
	File source = ts.getScreenshotAs(OutputType.FILE);
	try {
		FileUtils.copyFile(source, new File("./CSUSM_Webpage_test7_execution/"+timestamp() +"  "+screenshotName +".png"));
		FileUtils.copyFile(source, new File("//E:\\Major Project\\CSUSM_Webpage_Test7\\"+timestamp() +"  "+screenshotName +".png"));
	} 
	catch (Exception e) 
	{
	System.out.println("Exception while taking screenshot"+e.getMessage());
		}	
	}
	
}
