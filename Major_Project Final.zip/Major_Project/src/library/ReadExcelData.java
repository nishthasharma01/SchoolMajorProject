package library;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.xmlbeans.impl.util.Base64;

public class ReadExcelData {

	public static void encode_excelData() throws Exception{
		
		File src = new File("E:\\Major Project\\Project\\TestData.xlsx");
		
		FileInputStream fis = new FileInputStream(src);
		
		XSSFWorkbook wb = new XSSFWorkbook (fis); 
		
		XSSFSheet sheet1 = wb.getSheetAt(0);
		
		String data1 = sheet1.getRow(1).getCell(0).getStringCellValue();
		
		System.out.println("The excel data is:" + data1);
		
		byte[] encoded_data = Base64.encode(data1.getBytes());
		
//		System.out.println("String before encoding :"+data1);
//		System.out.println("String after encoding :"+new String(encoded_data));
//		
		byte[] decoded_data = Base64.decode(encoded_data);
	//	System.out.println("String after decoding :"+new String(decoded_data));
		
		
		
String data2 = sheet1.getRow(1).getCell(1).getStringCellValue();
		
		System.out.println("The excel data is:" + data2);
		
		byte[] encoded_data2 = Base64.encode(data2.getBytes());
		
//		System.out.println("String before encoding :"+data2);
//		System.out.println("String after encoding :"+new String(encoded_data2));
//		
		byte[] decoded_data2 = Base64.decode(encoded_data2);
		//System.out.println("String after decoding :"+new String(decoded_data2));
		
		
		
	}
	
}
