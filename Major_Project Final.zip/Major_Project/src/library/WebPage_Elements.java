package library;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import webDriver_info.WebDriver_Browser_class;

public class WebPage_Elements {

	public static void main(String args[]){
		
		WebDriver driver =  WebDriver_Browser_class.start_browser_func("chrome","https://www.csusm.edu/");
		
		List<WebElement> elements = driver.findElements(By.xpath("//*"));
		
		System.out.println(Integer.toString(elements.size()));
	//	System.out.println(elements);
		
		for(WebElement el:elements){
			System.out.println(el.getTagName() + " : "+ el.getText());
		//	System.out.println(elements);
		}
	}
	
}
