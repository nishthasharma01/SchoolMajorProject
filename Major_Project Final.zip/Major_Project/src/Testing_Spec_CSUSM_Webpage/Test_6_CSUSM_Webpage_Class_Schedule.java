package Testing_Spec_CSUSM_Webpage;

import java.io.FileOutputStream;
import java.io.PrintStream;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

//import Page_Object_design.CSUSM_Webpage;
//import library.Utility;
//import webDriver_info.WebDriver_Browser_class;
import Page_Object_design.CSUSM_Webpage_Class_Schedule;

public class Test_6_CSUSM_Webpage_Class_Schedule extends BaseClass_extentReport {
	
	@Test
	public void verify_CSUSM_Class_Schedule () throws Exception
	{
		System.setOut(new PrintStream(new FileOutputStream("E:\\Major Project\\CSUSM_Webpage_Test6\\output.txt"))); 
		System.out.println("Test_6_CSUSM_Webpage Class Schedule output");
		
		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_6_CSUSM_Webpage_Class_Schedule", "Verify the class schedule page");
			
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");
		CSUSM_Webpage_Class_Schedule verify_Class_schedle = new CSUSM_Webpage_Class_Schedule(driver);
		test.pass("navigated to the csusm.edu");

		//Verify the web page heading, title and print it
		WebElement webpage_heading= driver.findElement(By.xpath("//*[@id='ga-hp-header-home']"));
		System.out.println(webpage_heading.getText());
		String page_title = driver.getTitle();
		System.out.println(page_title);
		utility_obj.captureScreenshots_CSUSM_webpage_test6(driver, "CSUSM Home page_1");
		test.pass("navigated to the csusm.edu Home page");
			
		//Scroll the web page down and take the screen shot	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		utility_obj.captureScreenshots_CSUSM_webpage_test6(driver, "CSUSM Home page_2");

		//go to Academics > Class Schedule
		verify.academics_tab_func();	
		test.pass("navigated to the Academics tab");
		verify_Class_schedle.class_schedule_func();
		test.pass("navigated to the class schedule tab");
		String class_schedule_page_title = driver.getTitle();
		WebElement webpage_heading1= driver.findElement(By.xpath("//*[@id='maincontent']/div/h1"));
		System.out.println(webpage_heading1.getText());
		System.out.println(class_schedule_page_title);
		utility_obj.captureScreenshots_CSUSM_webpage_test6(driver, "Class Schedule page");
			
		//Click Browse/Search courses button
		//Scroll the web page down
		JavascriptExecutor js2 = (JavascriptExecutor) driver;
		js2.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		verify_Class_schedle.browse_search_course_func();
		test.pass("clicked the browse/search button");
		String schedule_classes_page_title = driver.getTitle();
		//WebElement webpage_heading2= driver.findElement(By.xpath("//*[@id='DERIVED_CLSRCH_SS_TRANSACT_TITLE']"));
		//System.out.println(webpage_heading2.getText());
		System.out.println(schedule_classes_page_title);
		utility_obj.captureScreenshots_CSUSM_webpage_test6(driver, "View schedule of classes page");
		
		
		//close the browser	
		driver.quit();
	}
}
