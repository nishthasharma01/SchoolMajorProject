package Testing_Spec_CSUSM_Webpage;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;


public class Test_3_CSUSM_webpage_CampusLife extends BaseClass_extentReport {

	@Test
	public void verify_Campus_life_tab() throws FileNotFoundException
	{
		System.setOut(new PrintStream(new FileOutputStream("E:\\Major Project\\CSUSM_Webpage_Test3\\output.txt"))); 
		System.out.println("Test_3_CSUSM_Webpage_CampusLife output");
		
		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_3_CSUSM_webpage_CampusLife", "Verify the campus life page");
		
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");
		test.pass("navigated to the csusm.edu");
		
		//Verify the web page heading, title and print it
		WebElement webpage_heading= driver.findElement(By.xpath("//*[@id='ga-hp-header-home']"));
		System.out.println(webpage_heading.getText());
		String page_title = driver.getTitle();
		System.out.println(page_title);
		utility_obj.captureScreenshots_CSUSM_webpage_test3(driver, "CSUSM Home page_1");
		test.pass("navigated to the csusm.edu Home page");

		//Scroll the web page down and take the screen shot	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		utility_obj.captureScreenshots_CSUSM_webpage_test3(driver, "CSUSM Home page_2");

		//go to Campus Life > Living On Campus
		verify.campus_life_tab_func();	
		verify.living_on_campus_subTab_func();
		test.pass("navigated to the Campus Life > Living On Campus page");
		String course_catalog_page_title = driver.getTitle();
		WebElement webpage_heading1= driver.findElement(By.xpath("//*[@id='maincontent']/div/h1"));
		System.out.println(webpage_heading1.getText());
		System.out.println(course_catalog_page_title);
		utility_obj.captureScreenshots_CSUSM_webpage_test3(driver, "Living on Campus page");
		test.pass("Living On Campus page details");
		
		driver.quit();

	}

}
