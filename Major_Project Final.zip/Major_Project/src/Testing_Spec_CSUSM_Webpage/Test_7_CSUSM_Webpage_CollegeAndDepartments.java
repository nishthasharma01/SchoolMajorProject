package Testing_Spec_CSUSM_Webpage;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

import org.openqa.selenium.By;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

//import Page_Object_design.CSUSM_Webpage;
//import library.Utility;
//import webDriver_info.WebDriver_Browser_class;
import Page_Object_design.CSUSM_Webpage_College_Department;

public class Test_7_CSUSM_Webpage_CollegeAndDepartments extends BaseClass_extentReport{
	@Test
	public void verify_collegeDepartment_webpage() throws FileNotFoundException
	{
		System.setOut(new PrintStream(new FileOutputStream("E:\\Major Project\\CSUSM_Webpage_Test7\\output.txt"))); 
		System.out.println("Test_7_CSUSM_Webpage College & Departments output");
		
		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_7_CSUSM_Webpage_CollegeAndDepartments", "Verify the college and departments");
		
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");
		CSUSM_Webpage_College_Department verify_collegeDept = new CSUSM_Webpage_College_Department(driver);
		test.pass("navigated to the csusm.edu");
		
		//Verify the web page heading, title and print it
		WebElement webpage_heading= driver.findElement(By.xpath("//*[@id='ga-hp-header-home']"));
		System.out.println(webpage_heading.getText());
		String page_title = driver.getTitle();
		System.out.println(page_title);
		utility_obj.captureScreenshots_CSUSM_webpage_test7(driver, "CSUSM Home page1");
		test.pass("navigated to the csusm.edu Home page");
		
		//Scroll the web page down and take the screen shot	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		utility_obj.captureScreenshots_CSUSM_webpage_test7(driver, "CSUSM Home page_2");	

		//go to Academics > College & Departments
		verify.academics_tab_func();	
		test.pass("navigated to the Academics tab");
		verify_collegeDept.collegeDept_func();
		test.pass("navigated to the Academics > College & Departments");
		String collegeDept_page_title = driver.getTitle();
		System.out.println(collegeDept_page_title);
		utility_obj.captureScreenshots_CSUSM_webpage_test7(driver, "College & Departments page");	
		verify_collegeDept.collegeDeptHome_func();
		test.pass("navigated to the College & Departments Home page");
		utility_obj.captureScreenshots_CSUSM_webpage_test7(driver, "College & Departments Home page");
		verify_collegeDept.certificate_radioBtn_func();
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		utility_obj.captureScreenshots_CSUSM_webpage_test7(driver, "Certificate course details");
		verify_collegeDept.bachelor_radioBtn_func();
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		utility_obj.captureScreenshots_CSUSM_webpage_test7(driver, "Bachelor course details");
		verify_collegeDept.minor_radioBtn_func();
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		utility_obj.captureScreenshots_CSUSM_webpage_test7(driver, "minor course details");
		verify_collegeDept.master_radioBtn_func();
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		utility_obj.captureScreenshots_CSUSM_webpage_test7(driver, "Master course details");
		verify_collegeDept.credential_radioBtn_func();
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		utility_obj.captureScreenshots_CSUSM_webpage_test7(driver, "Credential course details");
		test.pass("Verified all the options");
		
		driver.quit();
	}
}
