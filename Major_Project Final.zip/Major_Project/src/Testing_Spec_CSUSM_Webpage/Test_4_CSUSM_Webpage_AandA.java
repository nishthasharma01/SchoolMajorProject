package Testing_Spec_CSUSM_Webpage;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;


public class Test_4_CSUSM_Webpage_AandA extends BaseClass_extentReport {

	@Test
	public void verify_AdmissionsAndAid() throws FileNotFoundException 
	{
		System.setOut(new PrintStream(new FileOutputStream("E:\\Major Project\\CSUSM_Webpage_Test4\\output.txt"))); 
		System.out.println("Test_4_CSUSM_Webpage Admissions & Aid output");

		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_4_CSUSM_Webpage_AandA", "Verify the Admissions and Aid page");
		
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");
		test.pass("navigated to the csusm.edu");

		//Verify the web page heading, title and print it
		WebElement webpage_heading= driver.findElement(By.xpath("//*[@id='ga-hp-header-home']"));
		System.out.println(webpage_heading.getText());
		String page_title = driver.getTitle();
		System.out.println(page_title);
		utility_obj.captureScreenshots_CSUSM_webpage_test4(driver, "CSUSM Home page1");
		test.pass("navigated to the csusm.edu Home page");

		//go to Admission and Aid tab 
		verify.admissionAnd_Aid_func();

		//go to Admission and Aid tab > Admission and Student OutReach tab
		verify.admissions_StudentOutReach_func();
		String admissionAndAid_page_title = driver.getTitle();
		test.pass("navigated to the Admission and Aid tab > Admission and Student OutReach tab");
		System.out.println(admissionAndAid_page_title);
		WebElement webpage_heading1= driver.findElement(By.xpath("//*[@id='maincontent']/div/h1"));
		System.out.println(webpage_heading1.getText());
		utility_obj.captureScreenshots_CSUSM_webpage_test4(driver, "Admission and Student outreach page");
		test.pass("Admissions and Aid page details");

		driver.quit();	


	}
}
