package Testing_Spec_CSUSM_Webpage;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;


public class Test_2_CSUSM_Webpage_About_tab extends BaseClass_extentReport {

	@Test
	public void verify_About_tab() throws FileNotFoundException
	{
		System.setOut(new PrintStream(new FileOutputStream("E:\\Major Project\\CSUSM_Webpage_Test2\\output.txt"))); 
		System.out.println("Test_2_CSUSM_Webpage_About_tab output");
		
		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_2_CSUSM_Webpage_About_tab", "Verify the About tab");
		
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");
		test.pass("navigated to the csusm.edu");
		
		//Verify the web page heading, title and print it
		WebElement webpage_heading= driver.findElement(By.xpath("//*[@id='ga-hp-header-home']"));
		System.out.println(webpage_heading.getText());
		String page_title = driver.getTitle();
		System.out.println(page_title);
		utility_obj.captureScreenshots_CSUSM_webpage_test2(driver, "CSUSM Home page1");
		test.pass("navigated to the csusm.edu Home page");
		
		//Scroll the web page down and take the screen shot	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
		utility_obj.captureScreenshots_CSUSM_webpage_test2(driver, "CSUSM Home page_2");	

		//go to ABOUT > About CSUSM
		verify.about_tab_func();
		verify.about_CSUSM_subTab_func();
		test.pass("navigated to the ABOUT > About CSUSM webpage");
		String About_CSUSM_page_title = driver.getTitle();
		WebElement webpage_heading1= driver.findElement(By.xpath("/html/body/div/div[4]/center/h1"));
		System.out.println(webpage_heading1.getText());
		System.out.println(About_CSUSM_page_title);
		utility_obj.captureScreenshots_CSUSM_webpage_test2(driver, "About CSUSM page");
		test.pass("About tab details");

		driver.quit();

	}

}
