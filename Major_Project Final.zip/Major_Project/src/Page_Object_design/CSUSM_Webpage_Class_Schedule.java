package Page_Object_design;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CSUSM_Webpage_Class_Schedule {
	WebDriver driver;
	
	By class_schedule = By.xpath("//*[@id='ga-hp-academics-schedule-lg']");
	By browse_search_courses_btn = By.xpath("/html/body/div[5]/div[2]/div[4]/div/div[1]/div/p[6]/a");
	
	//constructor
			public CSUSM_Webpage_Class_Schedule(WebDriver driver)
			{
				this.driver=driver;	
			}
			
			//Class Schedule tab
			public void class_schedule_func()
			{
				driver.findElement(class_schedule).click();
			}
			
			//Browser/Search courses button
			public void browse_search_course_func(){
				driver.findElement(browse_search_courses_btn).click();
			}
			
}
