package Page_Object_design;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CSUSM_Webpage_College_Department {
WebDriver driver;
	
By collegeDept_btn = By.xpath("//*[@id='ga-hp-academics-colleges-lg']");
By collegeDept_Homebtn = By.xpath("/html/body/div[5]/div[2]/div[1]/div/ul/li[1]/a/span");
By certificate_radioBtn = By.xpath("/html/body/div[5]/div[2]/div[4]/div/div[1]/div/fieldset/label[2]/input");
By bachelor_radioBtn = By.xpath("/html/body/div[5]/div[2]/div[4]/div/div[1]/div/fieldset/label[3]/input");
By minor_radioBtn = By.xpath("/html/body/div[5]/div[2]/div[4]/div/div[1]/div/fieldset/label[4]/input");
By master_radioBtn = By.xpath("/html/body/div[5]/div[2]/div[4]/div/div[1]/div/fieldset/label[5]/input");
By credential_radioBtn = By.xpath("/html/body/div[5]/div[2]/div[4]/div/div[1]/div/fieldset/label[6]/input");

		//constructor
		public CSUSM_Webpage_College_Department(WebDriver driver)
		{
			this.driver=driver;	
		}
		
		//Functions
		public void collegeDept_func()
		{
			driver.findElement(collegeDept_btn).click();
		}
		
		public void collegeDeptHome_func()
		{
			driver.findElement(collegeDept_Homebtn).click();
		}
		
		public void certificate_radioBtn_func()
		{
			driver.findElement(certificate_radioBtn).click();
		}
		
		public void bachelor_radioBtn_func()
		{
			driver.findElement(bachelor_radioBtn).click();
		}
		
		public void minor_radioBtn_func()
		{
			driver.findElement(minor_radioBtn).click();
		}
		
		public void master_radioBtn_func()
		{
			driver.findElement(master_radioBtn).click();
		}
		
		public void credential_radioBtn_func()
		{
			driver.findElement(credential_radioBtn).click();
		}
}
