package Page_Object_design;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class CSUSM_Webpage_CourseCatalog {

	WebDriver driver;
	
	//Course catalog tab
		By search_catalog_dropdown = By.xpath("//*[@id='select2-location-container']");    ////*[@id='location']
		By search_catalog_dd_course = By.xpath("//*[@id='select2-location-result-hq93-3']"); //*[@id="select2-location-result-b8ge-3"]
		By searchCatalog_TextBox = By.xpath("//*[@id='keyword']");
		By search_icon = By.xpath("//*[@id='keyword-submit-icon']/span[1]");
		By course_prefixCode = By.xpath("//*[@id='gateway-page']/body/table/tbody/tr[3]/td[2]/table/tbody/tr[2]/td[2]/table/tbody/tr/td/table[2]/tbody/tr[1]/td[1]");
		By course_prefixC = By.xpath("//*[@id='gateway-page']/body/table/tbody/tr[3]/td[2]/table/tbody/tr[2]/td[2]/table/tbody/tr/td/table[2]/tbody/tr[2]/td");
		
		//constructor
		public CSUSM_Webpage_CourseCatalog(WebDriver driver)
		{
			this.driver=driver;	
		}
		
		//Functions
		public void catalog_search_textBox_func()
		{
			driver.findElement(searchCatalog_TextBox).click();
		}
		
		//Function to enter the course from excel
		public void catalog_search_textBox_from_excel() throws Exception{
			
			File src = new File("E:\\nishtha\\CSUSM third sem\\Major Project\\Project\\TestData1.xlsx");
			FileInputStream fis = new FileInputStream(src);
			XSSFWorkbook wb2 = new XSSFWorkbook (fis); 
			XSSFSheet course_sheet = wb2.getSheetAt(0);
			int rowcount = course_sheet.getLastRowNum();
			System.out.println("Row count is:"+rowcount+1);
			
			for (int i=0; i<=rowcount; i++)
			{
			String data1 = course_sheet.getRow(i).getCell(0).getStringCellValue();
			System.out.println("Excel data is:"+data1);
			driver.findElement(searchCatalog_TextBox).sendKeys(data1);
			driver.findElement(search_icon).click();
			}
			wb2.close();
			
		}
		
		public void course_prefixCode_assert_func()
		{
			String course_perfix = driver.findElement(course_prefixCode).getText();
			//WebElement errorMessage= driver.findElement(By.xpath("//*[@id='errorText']"));
			Assert.assertEquals(course_perfix,"Courses - Prefix/Code Matches");
			System.out.println(course_perfix);
		}
		
}
