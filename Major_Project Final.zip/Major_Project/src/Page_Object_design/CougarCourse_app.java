package Page_Object_design;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.xmlbeans.impl.util.Base64;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;


public class CougarCourse_app {

WebDriver driver;

//login elements
By campus_apps = By.xpath("/html/body/div/section[2]/div/div[2]/div/div[3]/div[2]/a/span[1]");
By cougar_courses_btn = By.xpath("//*[@id='app-dd']/ul/li[2]/a/span");
By login_btn2 = By.xpath("//*[@id='above-header']/div/div[2]/form/button");
By login_btn1 = By.xpath("//*[@id='mr-nav']/div/a");
By username2= By.xpath("//*[@id='userNameInput']");
By username1= By.xpath("//*[@id='username']");
By password2 = By.xpath("//*[@id='passwordInput']");
By password1 = By.xpath("//*[@id='password']");
By signIn_btn2 = By.xpath("//*[@id='submitButton']");
By signIn_btn1 = By.xpath("//*[@id='snap-pm-content']/form/input[2]");
By signIn_btn3 = By.xpath("//*[@id='region-main']/div/div/div/center/form/input");

// All tabs elements
By profile_tab = By.xpath("//*[@id='snap-pm-header-quicklinks']/a[1]");
By dashBoard_tab = By.xpath("//*[@id='snap-pm-header-quicklinks']/a[2]");
By prefrence_tab = By.xpath("//*[@id='snap-pm-header-quicklinks']/a[3]");
By grades_tab = By.xpath("//*[@id='snap-pm-header-quicklinks']/a[4]");

// Profile tab elements
By editProfile_btn = By.xpath("//*[@id='region-main']/div[3]/div/div/section[1]/ul/li[1]/span/a");
By gradesOverview_btn = By.xpath("//*[@id='region-main']/div[3]/div/div/section[4]/ul/li[2]/span/a");

// Dashborad tab elements
By course1_btn = By.xpath("//*[@id='course-info-container-25201-13']/div/a/span[4]");
By course2_btn = By.xpath("//*[@id='course-info-container-25364-13']/div/a/span[4]");
By course3_btn = By.xpath("//*[@id='course-info-container-22995-13']/div/a/span[4]");
By course4_btn = By.xpath("//*[@id='course-info-container-17399-13']/div/a/span[4]");

//Courses elements
By myCourse_btn = By.xpath("//*[@id='snap-pm-trigger']/span[1]");

By logout_btn = By.xpath("//*[@id='snap-pm-logout']"); 
By invalid_credential = By.xpath("//*[@id='errorText']");
By course_lib_thesis = By.xpath("//*[@id='snap-pm-courses-current-cards']/div[1]/div/h3/a");


//constructor
public CougarCourse_app(WebDriver driver)
{
	this.driver=driver;	
}

//Login Function
public void generalFunc() throws IOException
{
	JavascriptExecutor js = (JavascriptExecutor) driver;
	driver.findElement(campus_apps).click();
	js.executeScript("window.scrollBy(0,document.body.scrollHeight);");
	driver.findElement(cougar_courses_btn).click();
	driver.findElement(login_btn1).click();
}

public void login_Button_func(){
	driver.findElement(login_btn1).click();
}


//Function to enter the username from excel
public String enter_username_from_excel() throws Exception{
		
	File src = new File("E:\\Major Project\\Project\\TestData.xlsx");
	FileInputStream fis = new FileInputStream(src);
	XSSFWorkbook wb = new XSSFWorkbook (fis); 
	XSSFSheet sheet1 = wb.getSheetAt(0);
	String data1 = sheet1.getRow(1).getCell(0).getStringCellValue();	
	byte[] encoded_data = Base64.encode(data1.getBytes());
	byte[] decoded_data = Base64.decode(encoded_data);
	String str_decoded = new String(decoded_data);
	driver.findElement(username2).sendKeys(str_decoded);
	
	wb.close();
	
	return str_decoded;	
}

//Function to enter the password from excel
public String enter_password_from_excel() throws Exception{
	
	File src = new File("E:\\Major Project\\Project\\TestData.xlsx");
	FileInputStream fis = new FileInputStream(src);
	XSSFWorkbook wb = new XSSFWorkbook (fis); 
	XSSFSheet sheet1 = wb.getSheetAt(0);
	String data2 = sheet1.getRow(1).getCell(1).getStringCellValue();
	byte[] encoded_data2 = Base64.encode(data2.getBytes());
	byte[] decoded_data2 = Base64.decode(encoded_data2);
	String str_decoded2 = new String(decoded_data2);
	driver.findElement(password2).sendKeys(str_decoded2);
	wb.close();
	
	return str_decoded2;	
}

//Function to enter the wrong password from excel
public String enter_pass_word_from_excel() throws Exception{
	
	File src = new File("E:\\Major Project\\Project\\TestData.xlsx");
	FileInputStream fis = new FileInputStream(src);
	XSSFWorkbook wb = new XSSFWorkbook (fis); 
	XSSFSheet sheet1 = wb.getSheetAt(0);
	String data2 = sheet1.getRow(2).getCell(1).getStringCellValue();
	byte[] encoded_data2 = Base64.encode(data2.getBytes());
	byte[] decoded_data2 = Base64.decode(encoded_data2);
	String str_decoded2 = new String(decoded_data2);
	driver.findElement(password2).sendKeys(str_decoded2);
	wb.close();
	
	return str_decoded2;	
}


//Click the signin button function
public void click_signIn_func()
{
	driver.findElement(signIn_btn2).click();
}


//Profile tab function
public void profile_tab_func()
{
	driver.findElement(profile_tab).click();
}

//Inside buttons of Profile tab function
public void edit_profile_func()
{
	driver.findElement(editProfile_btn).click();
}
public void grade_overview_func()
{
	driver.findElement(gradesOverview_btn).click();
}

//Dashboard function
public void dashboard_tab_func()
{driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.findElement(dashBoard_tab).click();
}

//inside buttons of dashboard tab
public void course1_func()
{
	driver.findElement(course1_btn).click();
}
public void course2_func()
{
	driver.findElement(course2_btn).click();
}
public void course3_func()
{
	driver.findElement(course3_btn).click();
}
public void course4_func()
{
	driver.findElement(course4_btn).click();
}

//Preference tab function
public void prefrence_tab_func()
{
	driver.findElement(prefrence_tab).click();
}

//Grades tab function
public void grades_tab_func()
{
	driver.findElement(grades_tab).click();
}

//Logout button function
public void logout_func()
{
	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	driver.findElement(logout_btn).click();
}

//Library course function
public void lib_course_func()
{
	driver.findElement(course_lib_thesis).click();
}

public void my_courseBtn_func()
{
	driver.findElement(myCourse_btn).click();
}

//Invalid credentials function
public void invalid_creds_func()
{
	WebElement errorMessage= driver.findElement(By.xpath("//*[@id='errorText']"));
	Assert.assertEquals(errorMessage.getText(),"Incorrect user ID or password. Type the correct user ID and password, and try again.");
	System.out.println(errorMessage.getText());
}

}

