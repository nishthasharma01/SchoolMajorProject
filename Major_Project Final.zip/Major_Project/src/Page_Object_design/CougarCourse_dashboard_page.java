package Page_Object_design;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CougarCourse_dashboard_page {
	
	WebDriver driver;
	
	// Dashboard tab elements
	By course1_btn = By.xpath("//*[@id='course-info-container-28925-6']/div/a/span[4]");
	By course2_btn = By.xpath("//*[@id='course-info-container-17399-6']/div/a/span[4]");
	By course3_btn = By.xpath("//*[@id='course-info-container-22995-13']/div/a/span[4]");
	By course4_btn = By.xpath("//*[@id='course-info-container-17399-13']/div/a/span[4]");
	
	//constructor
	public CougarCourse_dashboard_page(WebDriver driver)
	{
		this.driver=driver;	
	}
	
	//inside buttons of dashboard tab
	public void course1_func()
	{
		driver.findElement(course1_btn).click();
	}
	public void course2_func()
	{
		driver.findElement(course2_btn).click();
	}
	public void course3_func()
	{
		driver.findElement(course3_btn).click();
	}
	public void course4_func()
	{
		driver.findElement(course4_btn).click();
	}
	

}
