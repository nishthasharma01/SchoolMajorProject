package Page_Object_design;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CougarCourse_profile_page {

	WebDriver driver;
	
	// Profile tab elements
	By editProfile_btn = By.xpath("//*[@id='region-main']/div[3]/div/div/section[1]/ul/li[1]/span/a");
	By gradesOverview_btn = By.xpath("//*[@id='region-main']/div[3]/div/div/section[4]/ul/li[2]/span/a");
	
	//constructor
	public CougarCourse_profile_page(WebDriver driver)
	{
		this.driver=driver;	
	}
	
	//Inside buttons of Profile tab function
	public void edit_profile_func()
	{
		driver.findElement(editProfile_btn).click();
	}
	public void grade_overview_func()
	{
		driver.findElement(gradesOverview_btn).click();
	}
}
