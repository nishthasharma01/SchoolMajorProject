package Page_Object_design;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CougarCourse_preference_page {

WebDriver driver;
	
//Preference tab elements
By prefrence_tab = By.xpath("//*[@id='snap-pm-header-quicklinks']/a[3]");
By edit_profileBtn = By.xpath("//*[@id='region-main']/div/div/div[1]/div/div/div/div[1]/a");
	
	//constructor
	public CougarCourse_preference_page(WebDriver driver)
	{
		this.driver=driver;	
	}
	
	
	//Preference tab function
	public void prefrence_tab_func()
	{
		driver.findElement(prefrence_tab).click();
	}
	
	public void edit_profile_func()
	{
		driver.findElement(edit_profileBtn).click();
	}
	
}
