package Testing_Spec_cougar_course;

import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;

import java.io.FileOutputStream;
import java.io.PrintStream;

import org.openqa.selenium.JavascriptExecutor;


public class Test_2_CC_All_tabs extends BaseClass_extentReport_cc {

	@Test
	public void verify_all_tabs () throws Exception
	{
		System.setOut(new PrintStream(new FileOutputStream("E:\\Major Project\\CougarCourse_Test2\\output.txt"))); 
		System.out.println("Test_2_CougarCourse All tabs output");
		
		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_2_CC_All_tabs", "Test Execution Details");
		
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");
		test.pass("navigated to the csusm.edu");
		JavascriptExecutor js = (JavascriptExecutor) driver;

		//go to application
		access.generalFunc();
		utility_obj.captureScreenshots_cougarCourse_test2(driver, "Cougar_Course Login page");
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(2000);
		
		//Login into application 
		access.enter_username_from_excel();
		utility_obj.captureScreenshots_cougarCourse_test2(driver, "username");
		access.enter_password_from_excel();
		utility_obj.captureScreenshots_cougarCourse_test2(driver, "password");
		test.pass("navigated to the cougar course login page");
		access.click_signIn_func();
		String page_title = driver.getTitle();
		System.out.println(page_title);
		test.pass("Successfully logged in, navigated to the cougar course home page");
		utility_obj.captureScreenshots_cougarCourse_test2(driver, "Cougar Course Homepage");
		
		//profile tab
		access.profile_tab_func();
		utility_obj.captureScreenshots_cougarCourse_test2(driver, "profile_tab");
		test.pass("navigated to the profile tab");
		String profile_page_title = driver.getTitle();
		System.out.println(profile_page_title);
		access.my_courseBtn_func();

		//Dashboard tab
		Thread.sleep(2000);
		access.dashboard_tab_func();
		Thread.sleep(2000);
		utility_obj.captureScreenshots_cougarCourse_test2(driver, "Dashboard_tab");
		test.pass("navigated to the Dashboard tab");
		String dashboard_page_title = driver.getTitle();
		System.out.println(dashboard_page_title);
		Thread.sleep(5000);
		access.my_courseBtn_func();

		//Preference tab
		Thread.sleep(2000);
		access.prefrence_tab_func();
		utility_obj.captureScreenshots_cougarCourse_test2(driver, "Preference_tab");
		test.pass("navigated to the Preference tab");
		String prefrence_page_title = driver.getTitle();
		System.out.println(prefrence_page_title);
		Thread.sleep(2000);
		access.my_courseBtn_func();

		//Grades tab
		Thread.sleep(2000);
		access.grades_tab_func();
		utility_obj.captureScreenshots_cougarCourse_test2(driver, "grades_tab");
		test.pass("navigated to the Grades tab");
		String grade_page_title = driver.getTitle();
		System.out.println(grade_page_title);
		Thread.sleep(2000);
		access.my_courseBtn_func();
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(2000);
		
		//Logout from application
		access.logout_func();
		test.pass("Successfully Logged out from cougar course");
		utility_obj.captureScreenshots_cougarCourse_test2(driver, "Login page after logout");

		//Close the browser
		driver.quit();

	}


}
