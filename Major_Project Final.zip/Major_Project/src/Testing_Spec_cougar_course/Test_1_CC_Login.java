package Testing_Spec_cougar_course;

import java.io.FileOutputStream;
import java.io.PrintStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;


public class Test_1_CC_Login extends BaseClass_extentReport_cc {

	@Test
	public void verify_login () throws Exception
	{		
		System.setOut(new PrintStream(new FileOutputStream("E:\\Major Project\\CougarCourse_Test1\\output.txt"))); 
		System.out.println("Test_1_CougarCourse login output");
		
		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_1_CC_Login", "Test Execution Details");
		
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");
		test.pass("navigated to the csusm.edu");

		//go to application
		access.generalFunc();
		utility_obj.captureScreenshots_cougarCourse_test1(driver, "Cougar_Course Login page");
		
		//login to the application
		test.pass("Login button clicked, navigated to the cougar course login page");
		access.enter_username_from_excel();
		test.pass("Entered username into cougar course login page");
		utility_obj.captureScreenshots_cougarCourse_test1(driver, "Username");
		access.enter_pass_word_from_excel();
		test.pass("Entered incorrect password into cougar course login page");
		access.click_signIn_func();
		String page_title = driver.getTitle();
		System.out.println(page_title);
		utility_obj.captureScreenshots_cougarCourse_test1(driver, "Incorrect password error");
		
		//assert the error message
		WebElement errorMessage= driver.findElement(By.xpath("//*[@id='errorText']"));
		Assert.assertEquals(errorMessage.getText(),"Incorrect user ID or password. Type the correct user ID and password, and try again.");
		System.out.println(errorMessage.getText());
		test.pass("Error message asserted");
		
		Thread.sleep(2000);
		//Close the browser
		driver.quit();


	}
}
