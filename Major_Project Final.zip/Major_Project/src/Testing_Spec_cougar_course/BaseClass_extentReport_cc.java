package Testing_Spec_cougar_course;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import library.Utility;
import webDriver_info.WebDriver_Browser_class;
import Page_Object_design.CougarCourse_app;

public class BaseClass_extentReport_cc {

	public static ExtentReports extent;
	public static ExtentHtmlReporter htmlReporter;
	public static ExtentTest test;

	WebDriver driver =  WebDriver_Browser_class.start_browser_func("chrome","https://www.csusm.edu/");
	Utility utility_obj = new Utility();
	CougarCourse_app access = new CougarCourse_app(driver);
	
	@BeforeSuite
	public void setup()
	{
		htmlReporter = new ExtentHtmlReporter("Report_cc.html");
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
	}

	@AfterMethod
	public void getResult(ITestResult result)
	{
		if(result.getStatus()==ITestResult.FAILURE)
		{
			test.fail(MarkupHelper.createLabel(result.getName()+"Test case failed", ExtentColor.RED));
			test.fail(result.getThrowable());
		}
		else if(result.getStatus()==ITestResult.SUCCESS)
		{
			test.pass(MarkupHelper.createLabel(result.getName()+"Test case passed", ExtentColor.GREEN));
		}
		else
		{
			test.skip(MarkupHelper.createLabel(result.getName()+"Test case skipped", ExtentColor.YELLOW));
		}
	}

	@AfterSuite
	public void tesrDown()
	{
		extent.flush();
	}

}
