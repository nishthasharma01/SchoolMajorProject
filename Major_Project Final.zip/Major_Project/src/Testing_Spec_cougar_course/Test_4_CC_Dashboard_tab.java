package Testing_Spec_cougar_course;

import java.io.FileOutputStream;
import java.io.PrintStream;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;
import Page_Object_design.CougarCourse_dashboard_page;


public class Test_4_CC_Dashboard_tab extends BaseClass_extentReport_cc {

	@Test
	public void verify_profile_tab () throws Exception
	{
		System.setOut(new PrintStream(new FileOutputStream("E:\\Major Project\\CougarCourse_Test4\\output.txt"))); 
		System.out.println("Test_4_CougarCourse Dashboard tab output");
		
		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_4_CC_Dashboard_tab", "Test Execution Details");
		
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");
		CougarCourse_dashboard_page access_dashboard = new CougarCourse_dashboard_page(driver);
		test.pass("navigated to the csusm.edu");
		JavascriptExecutor js = (JavascriptExecutor) driver;

		//go to application
		access.generalFunc();
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(2000);
		utility_obj.captureScreenshots_cougarCourse_test4(driver, "Cougar_Course Login page");

		//Login into application using excel
		access.enter_username_from_excel();
		utility_obj.captureScreenshots_cougarCourse_test4(driver, "username");
		access.enter_password_from_excel();
		utility_obj.captureScreenshots_cougarCourse_test4(driver, "password");
		test.pass("navigated to the cougar course login page");
		access.click_signIn_func();
		String page_title = driver.getTitle();
		System.out.println(page_title);
		test.pass("Successfully logged in, navigated to the cougar course home page");
		utility_obj.captureScreenshots_cougarCourse_test4(driver, "Cougar Course Homepage");
				

		//Dashboard tab
		Thread.sleep(2000);
		access.dashboard_tab_func();
		utility_obj.captureScreenshots_cougarCourse_test4(driver, "Dashboard tab");
		test.pass("navigated to the cougar course Dashboard page");
		String dashboard_page_title = driver.getTitle();
		System.out.println(dashboard_page_title);

		
		//Go to course1 
		access_dashboard.course1_func();
		utility_obj.captureScreenshots_cougarCourse_test4(driver, "Course1 page");
		test.pass("navigated to the course1 page");
		String course1_page_title = driver.getTitle();
		System.out.println(course1_page_title);

		//Navigate back to previous page
		driver.navigate().back();

		//Go to course2
		access_dashboard.course2_func();
		utility_obj.captureScreenshots_cougarCourse_test4(driver, "Course2 page");
		test.pass("navigated to the course2 page");
		String course2_page_title = driver.getTitle();
		System.out.println(course2_page_title);

//		driver.navigate().back();
//		Thread.sleep(2000);
//		access_dashboard.course3_func();
//		utility_obj.captureScreenshots_cougarCourse_test4(driver, "Course3_page");
//		String course3_page_title = driver.getTitle();
//		System.out.println(course3_page_title);

//		driver.navigate().back();
//		access_dashboard.course4_func();
//		utility_obj.captureScreenshots_cougarCourse_test4(driver, "Course4_page");
//		String course4_page_title = driver.getTitle();
//		System.out.println(course4_page_title);

		access.my_courseBtn_func();

		//Logout from application
		access.logout_func();
		test.pass("Successfully Logged out from cougar course");
		utility_obj.captureScreenshots_cougarCourse_test4(driver, "Login page after logout");

		//Close the browser
		driver.quit();
	}

}
