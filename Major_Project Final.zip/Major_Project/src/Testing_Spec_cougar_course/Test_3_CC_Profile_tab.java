package Testing_Spec_cougar_course;

import java.io.FileOutputStream;
import java.io.PrintStream;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import Page_Object_design.CougarCourse_profile_page;


public class Test_3_CC_Profile_tab extends BaseClass_extentReport_cc {

	@Test
	public void verify_profile_tab () throws Exception
	{	
		System.setOut(new PrintStream(new FileOutputStream("E:\\Major Project\\CougarCourse_Test3\\output.txt"))); 
		System.out.println("Test_3_CougarCourse Profile tab output");
		
		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_3_CC_Profile_tab", "Test Execution Details");
		
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");
		CougarCourse_profile_page access_profile = new CougarCourse_profile_page(driver);
		test.pass("navigated to the csusm.edu");
		JavascriptExecutor js = (JavascriptExecutor) driver;

		//Go to application
		access.generalFunc();
		utility_obj.captureScreenshots_cougarCourse_test3(driver, "Cougar_Course Login page");
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(2000);

		//Login into application using excel
		access.enter_username_from_excel();
		utility_obj.captureScreenshots_cougarCourse_test3(driver, "username");
		access.enter_password_from_excel();
		utility_obj.captureScreenshots_cougarCourse_test3(driver, "password");
		test.pass("navigated to the cougar course login page");
		access.click_signIn_func();
		String page_title = driver.getTitle();
		System.out.println(page_title);
		test.pass("Successfully logged in, navigated to the cougar course home page");
		utility_obj.captureScreenshots_cougarCourse_test3(driver, "Cougar Course Homepage");

		
		//profile tab
		access.profile_tab_func();
		utility_obj.captureScreenshots_cougarCourse_test3(driver, "profile page");
		String profile_page_title = driver.getTitle();
		System.out.println(profile_page_title);
		test.pass("navigated to the cougar course Profile page");

		//go to edit profile page
		access_profile.edit_profile_func();
		utility_obj.captureScreenshots_cougarCourse_test3(driver, "edit profile page");
		String editProfile_page_title = driver.getTitle();
		System.out.println(editProfile_page_title);
		test.pass("navigated to the edit profile page");

		//navigate back to previous page
		driver.navigate().back();

		//go to grade overview page
		access_profile.grade_overview_func();
		utility_obj.captureScreenshots_cougarCourse_test3(driver, "gradeOverview page");
		test.pass("navigated to the grade overview page");
		String gradeOverview_page_title = driver.getTitle();
		System.out.println(gradeOverview_page_title);
		access.my_courseBtn_func();

		//Logout from application
		access.logout_func();
		test.pass("Successfully Logged out from cougar course");
		utility_obj.captureScreenshots_cougarCourse_test3(driver, "Login page after logout");

		//Close the browser
		driver.quit();

	}

}
