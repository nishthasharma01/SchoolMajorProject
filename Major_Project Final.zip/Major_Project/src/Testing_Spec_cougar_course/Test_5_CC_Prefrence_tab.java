package Testing_Spec_cougar_course;

import java.io.FileOutputStream;
import java.io.PrintStream;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import Page_Object_design.CougarCourse_preference_page;


public class Test_5_CC_Prefrence_tab extends BaseClass_extentReport_cc {

	@Test
	public void verify_this_course_tab () throws Exception
	{
		System.setOut(new PrintStream(new FileOutputStream("E:\\Major Project\\CougarCourse_Test5\\output.txt"))); 
		System.out.println("Test_5_CougarCourse Preference tab output");
		
		// creates a toggle for the given test, adds all log events under it    
		test = extent.createTest("Test_5_CC_Prefrence_tab", "Test Execution Details");
		
		// log(Status, details)
		test.log(Status.INFO, "Start the browser and go to csusm.edu");	
		CougarCourse_preference_page access_preference = new CougarCourse_preference_page(driver);
		test.pass("navigated to the csusm.edu");
		JavascriptExecutor js = (JavascriptExecutor) driver;

		//Go to application
		access.generalFunc();
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(2000);
		utility_obj.captureScreenshots_cougarCourse_test5(driver, "Cougar Course Login page");
		
		//Login into application 
		access.enter_username_from_excel();
		utility_obj.captureScreenshots_cougarCourse_test5(driver, "username");
		access.enter_password_from_excel();
		utility_obj.captureScreenshots_cougarCourse_test5(driver, "password");
		test.pass("navigated to the cougar course login page");
		access.click_signIn_func();
		String page_title = driver.getTitle();
		System.out.println(page_title);
		test.pass("Successfully logged in, navigated to the cougar course home page");
		utility_obj.captureScreenshots_cougarCourse_test5(driver, "Cougar Course Homepage");
		
		
		//Preference tab
		Thread.sleep(2000);
		access_preference.prefrence_tab_func();
		utility_obj.captureScreenshots_cougarCourse_test5(driver, "Preference page");
		test.pass("navigated to the Preference tab");
		String prefrence_page_title = driver.getTitle();
		System.out.println(prefrence_page_title);
		access_preference.edit_profile_func();
		utility_obj.captureScreenshots_cougarCourse_test5(driver, "Preference tab edit page");
		test.pass("navigated to the Preference tab edit profile button");
		Thread.sleep(2000);
		access.my_courseBtn_func();
		
		//Logout from application
		access.logout_func();
		test.pass("Successfully Logged out from cougar course");
		utility_obj.captureScreenshots_cougarCourse_test5(driver, "Login page after logout");

		//Close the browser
		driver.quit();
	}


}
